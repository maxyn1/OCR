from tkinter import *
from PIL import Image
import pytesseract
import camera
# Include tesseract executable in your path
pytesseract.pytesseract.tesseract_cmd = r"C:\Users\HP\AppData\Local\Tesseract-OCR\tesseract.exe"

# Create an image object of PIL library
image = Image.open('captured_image.jpg')
# pass image into pytesseract module
# pytesseract is trained in many languages
image_to_text = pytesseract.image_to_string(image, lang='eng')
root=Tk()
root.geometry("900x700")
text=Text(root,height=40,width=80,bg="yellow")
text.insert(END,image_to_text)
text.pack()

root.mainloop()
# Print the text
print(image_to_text)
